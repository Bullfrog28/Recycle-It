package edu.purdue.jgiampao.recycle_client;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class mark_location extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark_location2);
    }
}
