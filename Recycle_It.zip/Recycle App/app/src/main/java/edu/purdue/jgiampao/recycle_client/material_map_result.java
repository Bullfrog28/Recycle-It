package edu.purdue.jgiampao.recycle_client;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class material_map_result extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private OkHttpClient client = new OkHttpClient();
    private String jsonRes = "";
    private String parseList[];
    //private static String strList;

    @Override
    protected synchronized void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material_map_result);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    //String inputMaterialStr = getIntent().getStringExtra("materialType");


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public synchronized void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // gets data from server
        try {
            //System.out.println("SUCCESS BEFORE");
            //String strList = getHTML();
            //System.out.println("SUCCESS AFTER");
            //System.out.flush();
            run("https://webhooks.mongodb-stitch.com/api/client/v2.0/app/testtransfer-spfqv/service/talk/incoming_webhook/getAll");
            //parseList[] = jsonRes.split("lat");

            for (int listIndex = 1; listIndex < parseList.length; listIndex = listIndex + 1) {
                // parse values
                double lat = Double.parseDouble(parseList[listIndex].substring(3, parseList[listIndex].indexOf(",") - 1));
                parseList[listIndex] = parseList[listIndex].substring(parseList[listIndex].indexOf(",") + 8);
                double lng = Double.parseDouble(parseList[listIndex].substring(0, parseList[listIndex].indexOf("\"")));
                parseList[listIndex] = parseList[listIndex].substring(parseList[listIndex].indexOf("\"") + 10);
                parseList[listIndex] = parseList[listIndex].substring(0, parseList[listIndex].indexOf("\""));
                String types = parseList[listIndex];
                //String[] splitTypes = types.split(", "); // not sure if necessary

                // generate marker
                LatLng newMarker = new LatLng(lat, lng);
                mMap.addMarker(new MarkerOptions().position(newMarker).visible(true));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(newMarker));

            }
        } catch (java.lang.Exception ex) {
            System.out.println(ex.getMessage());
        }

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    public static synchronized String getHTML() throws Exception {
        String urlToRead = "https://webhooks.mongodb-stitch.com/api/client/v2.0/app/testtransfer-spfqv/service/talk/incoming_webhook/getAll";
        StringBuilder result = new StringBuilder();
        URL url = new URL(urlToRead);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream())); // ERROR HERE
        System.out.println("SUCCESS IN getHTML()"); System.out.flush();
        String line;
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }
        rd.close();
        return result.toString();
    }

    public void run(String url){
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                try {
                    ResponseBody body = response.body();

                    // This is the JSON response as a string
                    jsonRes = body.string();
                    parseList = jsonRes.split("lat");
                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
    }
}
