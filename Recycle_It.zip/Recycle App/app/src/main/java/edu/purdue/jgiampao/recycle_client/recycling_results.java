package edu.purdue.jgiampao.recycle_client;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class recycling_results extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycling_results);

        if (getIntent().getExtras() != null) {

            String inputMaterialStr = getIntent().getStringExtra("materialType");

            TextView materialTV = (TextView)findViewById(R.id.varMaterialTV);
            materialTV.setText(inputMaterialStr);

            System.out.println("\n\nSUCCESS\n\n");
            //removeView(materialTV);
            //setContentView(materialTV);

        } else { //first time entering the app
            System.out.println("ERROR W/INTENT");

            String inputMaterialStr = "ERROR";

            TextView materialTV = (TextView)findViewById(R.id.varMaterialTV);
            materialTV.setText(inputMaterialStr);
            setContentView(materialTV);
        }



    }
}
